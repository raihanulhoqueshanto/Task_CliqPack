export const contactlists= [
  {
    "id": 1,
    "name": "John Doe",
    "email": "john.doe@example.com",
    "phone": "+1-555-123-4567",
    "address": "123 Main St, Cityville, State, 12345"
  },
  {
    "id": 2,
    "name": "Jane Smith",
    "email": "jane.smith@example.com",
    "phone": "+1-555-987-6543",
    "address": "456 Oak St, Townsville, State, 56789"
  },
  {
    "id": 3,
    "name": "Michael Johnson",
    "email": "michael.johnson@example.com",
    "phone": "+1-555-567-8901",
    "address": "789 Pine St, Villagetown, State, 67890"
  },
  {
    "id": 4,
    "name": "Emily Davis",
    "email": "emily.davis@example.com",
    "phone": "+1-555-234-5678",
    "address": "101 Elm St, Hamletsville, State, 23456"
  },
  {
    "id": 5,
    "name": "Robert White",
    "email": "robert.white@example.com",
    "phone": "+1-555-876-5432",
    "address": "202 Maple St, Boroughville, State, 34567"
  },
  {
    "id": 6,
    "name": "Amanda Brown",
    "email": "amanda.brown@example.com",
    "phone": "+1-555-345-6789",
    "address": "303 Birch St, Township, State, 45678"
  },
  {
    "id": 7,
    "name": "Daniel Lee",
    "email": "daniel.lee@example.com",
    "phone": "+1-555-654-3210",
    "address": "404 Cedar St, Countyville, State, 56789"
  },
  {
    "id": 8,
    "name": "Olivia Martinez",
    "email": "olivia.martinez@example.com",
    "phone": "+1-555-432-1098",
    "address": "505 Willow St, Districttown, State, 67890"
  },
  {
    "id": 9,
    "name": "William Taylor",
    "email": "william.taylor@example.com",
    "phone": "+1-555-210-9876",
    "address": "606 Spruce St, Precinctville, State, 78901"
  },
  {
    "id": 10,
    "name": "Sophia Anderson",
    "email": "sophia.anderson@example.com",
    "phone": "+1-555-789-0123",
    "address": "707 Fir St, Sectorville, State, 89012"
  },
  {
    "id": 11,
    "name": "Matthew Harris",
    "email": "matthew.harris@example.com",
    "phone": "+1-555-321-0987",
    "address": "808 Pinecone St, Divisiontown, State, 90123"
  },
  {
    "id": 12,
    "name": "Emma Wilson",
    "email": "emma.wilson@example.com",
    "phone": "+1-555-098-7654",
    "address": "909 Redwood St, Enclaveville, State, 01234"
  },
  {
    "id": 13,
    "name": "Christopher Garcia",
    "email": "christopher.garcia@example.com",
    "phone": "+1-555-765-4321",
    "address": "1010 Oaktree St, Blockville, State, 12345"
  },
  {
    "id": 14,
    "name": "Isabella Miller",
    "email": "isabella.miller@example.com",
    "phone": "+1-555-543-2109",
    "address": "1111 Mapleleaf St, Zoneville, State, 23456"
  },
  {
    "id": 15,
    "name": "Joseph Rodriguez",
    "email": "joseph.rodriguez@example.com",
    "phone": "+1-555-890-1234",
    "address": "1212 Cedarwood St, Clusterburg, State, 34567"
  },
  {
    "id": 16,
    "name": "Abigail Wilson",
    "email": "abigail.wilson@example.com",
    "phone": "+1-555-432-1098",
    "address": "1313 Birchtree St, Sectorburg, State, 45678"
  },
  {
    "id": 17,
    "name": "Ethan Davis",
    "email": "ethan.davis@example.com",
    "phone": "+1-555-098-7654",
    "address": "1414 Willowtree St, Zoneburg, State, 56789"
  },
  {
    "id": 18,
    "name": "Madison Thomas",
    "email": "madison.thomas@example.com",
    "phone": "+1-555-876-5432",
    "address": "1515 Pinecone St, Districtburg, State, 67890"
  },
  {
    "id": 19,
    "name": "Jackson Harris",
    "email": "jackson.harris@example.com",
    "phone": "+1-555-234-5678",
    "address": "1616 Redwoodtree St, Enclaveburg, State, 78901"
  },
  {
    "id": 20,
    "name": "Ava Taylor",
    "email": "ava.taylor@example.com",
    "phone": "+1-555-567-8901",
    "address": "1717 Oakwood St, Blockburg, State, 89012"
  }
]

